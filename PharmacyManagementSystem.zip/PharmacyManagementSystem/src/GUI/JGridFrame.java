package GUI;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;

import javax.swing.JComponent;
import javax.swing.JScrollPane;

public class JGridFrame extends JFrame {

    private JPanel center;


    private static final long serialVersionUID = 1L;

    public JGridFrame(JFrame parent, int rows, int columns, String title, boolean scroll) {
        super(300*columns, 150 + 65*rows, parent);
        JPanel panel = new JPanel(new BorderLayout(15, 15), 27, 27, 27, 27);
        panel.add(new GUI.JLabel(title, 25),
                BorderLayout.NORTH);

        center = new JPanel(new GridLayout(rows, columns, 20, 20), 10, 20, 10, 20);



        getContentPane().add(panel, BorderLayout.CENTER);

        if (scroll) {
            if (300*columns>350*4)
                setSize(new Dimension(300*4, getHeight()));
            if (150+65*rows>700)
                setSize(new Dimension(getWidth(), 700));
            JScrollPane pane = new JScrollPane(center);
            pane.setBackground(null);
            pane.getViewport().setBackground(null);
            pane.setBorder(null);
            pane.getViewport().setBorder(null);
            panel.add(pane, BorderLayout.CENTER);
        } else {
            panel.add(center, BorderLayout.CENTER);
        }
        setVisible(true);
    }

    public void addToGrid(JComponent c) {
        center.add(c);
    }

}
